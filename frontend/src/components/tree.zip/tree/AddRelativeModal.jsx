import React from "react";

const AddRelativeModal = ({
  relativeName,
  setRelativeName,
  selectedRelation,
  setSelectedRelation,
  onAdd,
  onClose,
}) => {
  return (
    <div
      className="tree-modal-overlay"
      onClick={onClose}
    >
      <div
        className="tree-modal"
        onClick={(event) => event.stopPropagation()}
      >
        {/* HEADER */}
        <div className="tree-modal-header">
          <h2>Add Family Member</h2>

          <button
            className="modal-close"
            onClick={onClose}
          >
            ×
          </button>
        </div>

        {/* RELATIONSHIP */}
        <div className="tree-form-group">
          <label>Relationship</label>

          <select
            value={selectedRelation}
            onChange={(event) =>
              setSelectedRelation(event.target.value)
            }
          >
            <option value="Father">Father</option>
            <option value="Mother">Mother</option>
            <option value="Brother">Brother</option>
            <option value="Sister">Sister</option>
            <option value="Spouse">Spouse</option>
            <option value="Son">Son</option>
            <option value="Daughter">Daughter</option>
          </select>
        </div>

        {/* NAME */}
        <div className="tree-form-group">
          <label>Name</label>

          <input
            type="text"
            placeholder="Enter family member name"
            value={relativeName}
            onChange={(event) =>
              setRelativeName(event.target.value)
            }
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                onAdd();
              }
            }}
          />
        </div>

        {/* ACTIONS */}
        <div className="tree-modal-actions">
          <button
            className="cancel-btn"
            onClick={onClose}
          >
            Cancel
          </button>

          <button
            className="add-btn"
            onClick={onAdd}
          >
            Add Relative
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddRelativeModal;