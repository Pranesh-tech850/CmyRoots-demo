
import React, { useState } from "react";

import {
  ReactFlow,
  useNodesState,
  useEdgesState,
} from "@xyflow/react";

import "@xyflow/react/dist/style.css";

import {
  User,
  UserPlus,
} from "lucide-react";

import familyTree from "../../assets/family-tree.png";

import "../../styles/TreePage.css";

import FamilyNode from "./FamilyNode";
import AddRelativeModal from "./AddRelativeModal";
import ProfileModal from "./ProfileModal";

/* =========================================================
   NODE TYPE
========================================================= */

const nodeTypes = {
  familyNode: FamilyNode,
};

/* =========================================================
   INITIAL NODE
========================================================= */

const initialNodes = [
  {
    id: "tom",

    type: "familyNode",

    position: {
      x: 500,
      y: 300,
    },

    data: {
      name: "Tom Smith",
      relation: "Me",
      isMe: true,
    },
  },
];

/* =========================================================
   INITIAL EDGES
========================================================= */

const initialEdges = [];

/* =========================================================
   RELATION CONFIGURATION

   Father    -> TOP
   Mother    -> TOP

   Brother   -> RIGHT
   Sister    -> LEFT
   Spouse    -> LEFT

   Son       -> BOTTOM
   Daughter  -> BOTTOM
========================================================= */

const RELATION_CONFIG = {
  Father: {
    direction: "top",
  },

  Mother: {
    direction: "top",
  },

  Brother: {
    direction: "right",
  },

  Sister: {
    direction: "left",
  },

  Spouse: {
    direction: "left",
  },

  Son: {
    direction: "bottom",
  },

  Daughter: {
    direction: "bottom",
  },
};

/* =========================================================
   TREE PAGE
========================================================= */

const TreePage = () => {

  /* =======================================================
     MODAL STATES
  ======================================================= */

  const [showAddRelative, setShowAddRelative] =
    useState(false);

  const [showProfile, setShowProfile] =
    useState(false);


  /* =======================================================
     FORM STATES
  ======================================================= */

  const [relativeName, setRelativeName] =
    useState("");

  const [selectedRelation, setSelectedRelation] =
    useState("Father");


  /* =======================================================
     SELECTED PERSON
  ======================================================= */

  const [selectedPersonId, setSelectedPersonId] =
    useState("tom");


  /* =======================================================
     REACT FLOW STATES
  ======================================================= */

  const [nodes, setNodes, onNodesChange] =
    useNodesState(initialNodes);

  const [edges, setEdges, onEdgesChange] =
    useEdgesState(initialEdges);


  /* =======================================================
     FIND SELECTED PERSON
  ======================================================= */

  const getSelectedPerson = () => {

    return nodes.find(
      (node) =>
        node.id === selectedPersonId
    );

  };


  /* =======================================================
     NODE CLICK
  ======================================================= */

  const handleNodeClick = (event, node) => {

    setSelectedPersonId(node.id);

    console.log(
      "Selected person:",
      node.data.name
    );

  };


  /* =======================================================
     GET RELATIVES OF SELECTED PERSON
  ======================================================= */

  const getRelatives = (relation) => {

    return nodes.filter((node) => {

      /* Don't count selected person */

      if (node.id === selectedPersonId) {
        return false;
      }


      /* Check relation */

      if (
        node.data.relation !== relation
      ) {
        return false;
      }


      /* Check whether connected */

      return edges.some((edge) => {

        return (

          (
            edge.source === node.id &&
            edge.target === selectedPersonId
          )

          ||

          (
            edge.target === node.id &&
            edge.source === selectedPersonId
          )

        );

      });

    });

  };


  /* =======================================================
     GET RELATION COUNT
  ======================================================= */

  const getRelationCount = (relation) => {

    return getRelatives(relation).length;

  };


  /* =======================================================
     GET POSITION FOR RELATION
  ======================================================= */

  const getPositionForRelation = (
    relation,
    selectedNode
  ) => {

    const selectedX =
      selectedNode.position.x;

    const selectedY =
      selectedNode.position.y;


    /* =====================================================
       SPACING
    ===================================================== */

    const horizontalGap = 220;

    const verticalGap = 180;


    /* =====================================================
       EXISTING RELATIVE COUNT
    ===================================================== */

    const count =
      getRelationCount(relation);


    /* =====================================================
       FATHER

                 Father
                    |
                   Tom
    ===================================================== */

    if (relation === "Father") {

      return {

        x:
          selectedX - 100,

        y:
          selectedY - verticalGap,

      };

    }


    /* =====================================================
       MOTHER

                 Mother
                    |
                   Tom
    ===================================================== */

    if (relation === "Mother") {

      return {

        x:
          selectedX + 100,

        y:
          selectedY - verticalGap,

      };

    }


    /* =====================================================
       BROTHER

                   Brother
                      |
            Tom ------------- Brother

       Multiple brothers move further right.
    ===================================================== */

    if (relation === "Brother") {

      return {

        x:
          selectedX +
          horizontalGap *
          (count + 1),

        y:
          selectedY,

      };

    }


    /* =====================================================
       SISTER

            Sister -------- Tom

       Multiple sisters move further left.
    ===================================================== */

    if (relation === "Sister") {

      return {

        x:
          selectedX -
          horizontalGap *
          (count + 1),

        y:
          selectedY,

      };

    }


    /* =====================================================
       SPOUSE

            Spouse -------- Tom
    ===================================================== */

    if (relation === "Spouse") {

      return {

        x:
          selectedX -
          horizontalGap,

        y:
          selectedY,

      };

    }


    /* =====================================================
       SON

                   Tom
                    |
                   Son
    ===================================================== */

    if (relation === "Son") {

      return {

        x:
          selectedX -
          80 +
          count * 180,

        y:
          selectedY +
          verticalGap,

      };

    }


    /* =====================================================
       DAUGHTER

                   Tom
                    |
                Daughter
    ===================================================== */

    if (relation === "Daughter") {

      return {

        x:
          selectedX -
          80 +
          count * 180,

        y:
          selectedY +
          verticalGap,

      };

    }


    /* =====================================================
       DEFAULT
    ===================================================== */

    return {

      x:
        selectedX + horizontalGap,

      y:
        selectedY,

    };

  };


  /* =======================================================
     GET CONNECTION
  ======================================================= */

  const getConnection = (
    relation,
    selectedNode,
    newNodeId
  ) => {


    /* =====================================================
       FATHER
       
       Father
          |
         Tom
    ===================================================== */

    if (relation === "Father") {

      return {

        id:
          `edge-${selectedNode.id}-${newNodeId}`,

        source:
          newNodeId,

        sourceHandle:
          "bottom",

        target:
          selectedNode.id,

        targetHandle:
          "top",

      };

    }


    /* =====================================================
       MOTHER
    ===================================================== */

    if (relation === "Mother") {

      return {

        id:
          `edge-${selectedNode.id}-${newNodeId}`,

        source:
          newNodeId,

        sourceHandle:
          "bottom",

        target:
          selectedNode.id,

        targetHandle:
          "top",

      };

    }


    /* =====================================================
       BROTHER
       
       Tom -------- Brother
    ===================================================== */

    if (relation === "Brother") {

      return {

        id:
          `edge-${selectedNode.id}-${newNodeId}`,

        source:
          selectedNode.id,

        sourceHandle:
          "right",

        target:
          newNodeId,

        targetHandle:
          "left",

      };

    }


    /* =====================================================
       SISTER
       
       Sister -------- Tom
    ===================================================== */

    if (relation === "Sister") {

      return {

        id:
          `edge-${selectedNode.id}-${newNodeId}`,

        source:
          newNodeId,

        sourceHandle:
          "right",

        target:
          selectedNode.id,

        targetHandle:
          "left",

      };

    }


    /* =====================================================
       SPOUSE
       
       Spouse -------- Tom
    ===================================================== */

    if (relation === "Spouse") {

      return {

        id:
          `edge-${selectedNode.id}-${newNodeId}`,

        source:
          newNodeId,

        sourceHandle:
          "right",

        target:
          selectedNode.id,

        targetHandle:
          "left",

      };

    }


    /* =====================================================
       SON
       
       Tom
        |
       Son
    ===================================================== */

    if (relation === "Son") {

      return {

        id:
          `edge-${selectedNode.id}-${newNodeId}`,

        source:
          selectedNode.id,

        sourceHandle:
          "bottom",

        target:
          newNodeId,

        targetHandle:
          "top",

      };

    }


    /* =====================================================
       DAUGHTER
       
       Tom
        |
       Daughter
    ===================================================== */

    if (relation === "Daughter") {

      return {

        id:
          `edge-${selectedNode.id}-${newNodeId}`,

        source:
          selectedNode.id,

        sourceHandle:
          "bottom",

        target:
          newNodeId,

        targetHandle:
          "top",

      };

    }


    /* =====================================================
       DEFAULT
    ===================================================== */

    return {

      id:
        `edge-${selectedNode.id}-${newNodeId}`,

      source:
        selectedNode.id,

      target:
        newNodeId,

      type:
        "smoothstep",

    };

  };


  /* =======================================================
     FIND SPOUSE
  ======================================================= */

  const getSpouse = () => {

    return nodes.find((node) => {

      if (
        node.data.relation !== "Spouse"
      ) {
        return false;
      }


      return edges.some((edge) => {

        return (

          (
            edge.source === selectedPersonId &&
            edge.target === node.id
          )

          ||

          (
            edge.target === selectedPersonId &&
            edge.source === node.id
          )

        );

      });

    });

  };


  /* =======================================================
     OPEN ADD RELATIVE
  ======================================================= */

  const openAddRelative = () => {

    if (!selectedPersonId) {

      setSelectedPersonId("tom");

    }

    setShowAddRelative(true);

  };


  /* =======================================================
     ADD RELATIVE
  ======================================================= */

  const handleAddRelative = () => {

    /* =====================================================
       VALIDATE NAME
    ===================================================== */

    if (!relativeName.trim()) {

      alert(
        "Please enter family member name"
      );

      return;

    }


    /* =====================================================
       GET SELECTED PERSON
    ===================================================== */

    const selectedNode =
      getSelectedPerson();


    if (!selectedNode) {

      alert(
        "Please select a family member first"
      );

      return;

    }


    /* =====================================================
       CREATE UNIQUE ID
    ===================================================== */

    const newNodeId =
      `${selectedRelation.toLowerCase()}-${Date.now()}`;


    /* =====================================================
       FIND SPOUSE
    ===================================================== */

    const spouseNode =
      getSpouse();


    /* =====================================================
       CALCULATE POSITION
    ===================================================== */

    let position;


    /* =====================================================
       CHILD

       If selected person has spouse:

             Tom ---- Spouse
               \      /
                \    /
                  Son

       Child is placed between both parents.
    ===================================================== */

    if (

      (
        selectedRelation === "Son" ||
        selectedRelation === "Daughter"
      )

      &&

      spouseNode

    ) {

      const parent1X =
        selectedNode.position.x;

      const parent2X =
        spouseNode.position.x;


      const parentY =
        Math.max(

          selectedNode.position.y,

          spouseNode.position.y

        );


      position = {

        x:
          (parent1X + parent2X) / 2,

        y:
          parentY + 180,

      };

    }


    /* =====================================================
       NORMAL RELATION
    ===================================================== */

    else {

      position =
        getPositionForRelation(
          selectedRelation,
          selectedNode
        );

    }


    /* =====================================================
       CREATE NEW NODE
    ===================================================== */

    const newNode = {

      id:
        newNodeId,

      type:
        "familyNode",

      position:
        position,

      data: {

        name:
          relativeName.trim(),

        relation:
          selectedRelation,

        isMe:
          false,

      },

    };


    /* =====================================================
       ADD NODE
    ===================================================== */

    setNodes((currentNodes) => [

      ...currentNodes,

      newNode,

    ]);


    /* =====================================================
       CHILD + SPOUSE

       Connect BOTH parents to child.
    ===================================================== */

    if (

      (
        selectedRelation === "Son" ||
        selectedRelation === "Daughter"
      )

      &&

      spouseNode

    ) {

      const parentEdge1 = {

        id:
          `edge-${selectedPersonId}-${newNodeId}`,

        source:
          selectedPersonId,

        sourceHandle:
          "bottom",

        target:
          newNodeId,

        targetHandle:
          "top",

        type:
          "smoothstep",

        style: {

          stroke:
            "#9ca3af",

          strokeWidth:
            1.5,

        },

      };


      const parentEdge2 = {

        id:
          `edge-${spouseNode.id}-${newNodeId}`,

        source:
          spouseNode.id,

        sourceHandle:
          "bottom",

        target:
          newNodeId,

        targetHandle:
          "top",

        type:
          "smoothstep",

        style: {

          stroke:
            "#9ca3af",

          strokeWidth:
            1.5,

        },

      };


      setEdges((currentEdges) => [

        ...currentEdges,

        parentEdge1,

        parentEdge2,

      ]);

    }


    /* =====================================================
       NORMAL SINGLE RELATION
    ===================================================== */

    else {

      const connection =
        getConnection(

          selectedRelation,

          selectedNode,

          newNodeId

        );


      const newEdge = {

        ...connection,

        type:
          "smoothstep",

        style: {

          stroke:
            "#9ca3af",

          strokeWidth:
            1.5,

        },

      };


      setEdges((currentEdges) => [

        ...currentEdges,

        newEdge,

      ]);

    }


    /* =====================================================
       RESET
    ===================================================== */

    setRelativeName("");

    setSelectedRelation("Father");

    setShowAddRelative(false);

  };


  /* =======================================================
     CLOSE ADD MODAL
  ======================================================= */

  const closeAddModal = () => {

    setRelativeName("");

    setSelectedRelation("Father");

    setShowAddRelative(false);

  };


  /* =======================================================
     SELECTED PERSON DATA
  ======================================================= */

  const selectedPerson =
    getSelectedPerson();


  /* =======================================================
     RENDER
  ======================================================= */

  return (

    <main className="tree-page">

      {/* =================================================
          HEADER
      ================================================= */}

      <div className="tree-header">

        <div>

          <h1>
            Family Tree
          </h1>

          <p>
            Explore and manage your family relationships
          </p>

        </div>


        {/* =================================================
            ACTION BUTTONS
        ================================================= */}

        <div className="tree-actions">

          {/* ADD RELATIVE */}

          <button
            className="tree-action-btn"
            onClick={openAddRelative}
          >

            <UserPlus size={18} />

            <span>
              Add Relative
            </span>

          </button>


          {/* PROFILE */}

          <button
            className="tree-action-btn"
            onClick={() =>
              setShowProfile(true)
            }
          >

            <User size={18} />

            <span>
              View Profile
            </span>

          </button>

        </div>

      </div>


      {/* =================================================
          FAMILY TREE
      ================================================= */}

      <section className="family-tree-area">

        {/* BACKGROUND */}

        <img
          src={familyTree}
          alt="Family Tree"
          className="family-tree-background"
        />


        {/* REACT FLOW */}

        <div className="family-tree-flow">

          <ReactFlow

            nodes={nodes}

            edges={edges}

            onNodesChange={
              onNodesChange
            }

            onEdgesChange={
              onEdgesChange
            }

            onNodeClick={
              handleNodeClick
            }

            nodeTypes={
              nodeTypes
            }


            /* -----------------------------------------
               NODE SETTINGS
            ----------------------------------------- */

            nodesDraggable={
              false
            }

            nodesConnectable={
              false
            }

            elementsSelectable={
              true
            }


            /* -----------------------------------------
               PAN / ZOOM
            ----------------------------------------- */

            panOnDrag={
              false
            }

            zoomOnScroll={
              false
            }

            zoomOnPinch={
              false
            }

            zoomOnDoubleClick={
              false
            }


            /* -----------------------------------------
               ZOOM RANGE
            ----------------------------------------- */

            minZoom={
              0.45
            }

            maxZoom={
              1
            }


            /* -----------------------------------------
               NO FIT VIEW
            ----------------------------------------- */

            defaultViewport={{
              x: 0,
              y: 0,
              zoom: 1,
            }}


            /* -----------------------------------------
               HIDE ATTRIBUTION
            ----------------------------------------- */

            proOptions={{
              hideAttribution:
                true,
            }}

          />

        </div>

      </section>


      {/* =================================================
          ADD RELATIVE MODAL
      ================================================= */}

      {showAddRelative && (

        <AddRelativeModal

          relativeName={
            relativeName
          }

          setRelativeName={
            setRelativeName
          }

          selectedRelation={
            selectedRelation
          }

          setSelectedRelation={
            setSelectedRelation
          }

          onAdd={
            handleAddRelative
          }

          onClose={
            closeAddModal
          }

        />

      )}


      {/* =================================================
          PROFILE MODAL
      ================================================= */}

      {showProfile && (

        <ProfileModal

          memberCount={
            nodes.length
          }

          selectedPerson={
            selectedPerson?.data
          }

          onClose={() =>
            setShowProfile(false)
          }

        />

      )}

    </main>

  );
};


export default TreePage;

