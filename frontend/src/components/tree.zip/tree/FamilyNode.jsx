import React from "react";
import { Handle, Position } from "@xyflow/react";
import { User } from "lucide-react";

const FamilyNode = ({ data }) => {
  return (
    <div
      className={`family-node ${
        data.isMe ? "family-node-me" : ""
      }`}
    >
      {/* TOP */}
      <Handle
        id="top"
        type="target"
        position={Position.Top}
        className="family-handle"
      />

      {/* BOTTOM */}
      <Handle
        id="bottom"
        type="source"
        position={Position.Bottom}
        className="family-handle"
      />

      {/* LEFT */}
      <Handle
        id="left"
        type="target"
        position={Position.Left}
        className="family-handle"
      />

      {/* RIGHT */}
      <Handle
        id="right"
        type="source"
        position={Position.Right}
        className="family-handle"
      />

      {/* AVATAR */}
      <div className="family-node-avatar">
        <User size={24} />
      </div>

      {/* NAME */}
      <div className="family-node-name">
        {data.name}
      </div>

      {/* RELATION */}
      <div className="family-node-relation">
        {data.relation}
      </div>
    </div>
  );
};

export default FamilyNode;